using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Shush
{
    public class OptSpec
    {
        public string Type, Key, Label, Unit = "", DefStr = "";
        public int Min, Max, DefInt;
        public string[] Choices;
    }

    public class FeatureSpec
    {
        public string Id, Name, Kind, DelayLabel, Sub, Cat;
        public int Delay, DelayMax = 250;
        public bool Auto;
        public List<OptSpec> Opts = new List<OptSpec>();
    }

    public class FeatureCfg
    {
        public bool Enabled { get; set; }
        public string Bind { get; set; } = "";
        public int Delay { get; set; }
        public Dictionary<string, int> Num { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, string> Str { get; set; } = new Dictionary<string, string>();
    }

    public class Settings
    {
        public int Version { get; set; } = 0;
        public Dictionary<string, FeatureCfg> Features { get; set; } = new Dictionary<string, FeatureCfg>();
        public Dictionary<string, string> Keys { get; set; } = new Dictionary<string, string>();
        public string ResetMethod { get; set; } = "Right Click";
        public int ScrollMs { get; set; } = 50;
        public int TapMs { get; set; } = 25;
        public bool RobloxOnly { get; set; } = true;
        public bool Debug { get; set; } = false;
        public string Theme { get; set; } = "Midnight";
        public bool HideTaskbar { get; set; } = true;
        public string UiKey { get; set; } = "INSERT";
        public string PanicKey { get; set; } = "F12";
        public int Fps { get; set; } = 144;
        public bool FpsFloor { get; set; } = true;
        public int Opacity { get; set; } = 100;
        public int Scale { get; set; } = 100;

        public static readonly string[] ThemeNames = { "Light", "Midnight", "Crimson", "Slate" };

        public static readonly Dictionary<string, string> DefaultKeys = new Dictionary<string, string>
        {
            { "edit", "G" }, { "pickup", "E" }, { "slot1", "F" }, { "slot2", "1" }, { "slot3", "2" }, { "slot4", "3" },
            { "slot5", "4" }, { "slot6", "5" }, { "slot7", "6" }, { "wall", "Z" }, { "floor", "X" }, { "ramp", "C" }, { "pyramid", "V" },
        };

        /// <summary>Fill anything missing, migrate old configs, so a partial/old file never causes errors.</summary>
        public void Fix()
        {
            if (Features == null) Features = new Dictionary<string, FeatureCfg>();
            if (Keys == null) Keys = new Dictionary<string, string>();
            foreach (var kv in DefaultKeys) if (!Keys.ContainsKey(kv.Key) || string.IsNullOrEmpty(Keys[kv.Key])) Keys[kv.Key] = kv.Value;
            foreach (var spec in Specs.All)
            {
                FeatureCfg f;
                if (!Features.TryGetValue(spec.Id, out f) || f == null)
                {
                    f = new FeatureCfg { Delay = spec.Delay };
                    Features[spec.Id] = f;
                }
                if (f.Num == null) f.Num = new Dictionary<string, int>();
                if (f.Str == null) f.Str = new Dictionary<string, string>();
                if (f.Bind == null) f.Bind = "";
                foreach (var o in spec.Opts)
                {
                    if (o.Type == "choice" || o.Type == "bind" || o.Type == "tiles") { if (!f.Str.ContainsKey(o.Key)) f.Str[o.Key] = o.DefStr; }
                    else if (!f.Num.ContainsKey(o.Key)) f.Num[o.Key] = o.DefInt;
                }
            }

            // old separate Drag Wall/Floor/Ramp/Pyramid macros -> one Auto Build macro
            var ab = Features["auto_build"];
            foreach (var p in Specs.Pieces)
            {
                FeatureCfg old;
                if (Features.TryGetValue("drag_" + p, out old) && old != null)
                {
                    if (!string.IsNullOrEmpty(old.Bind) && string.IsNullOrEmpty(ab.Str["bind_" + p])) ab.Str["bind_" + p] = old.Bind;
                    if (old.Enabled) ab.Enabled = true;
                    if (old.Str != null && old.Str.ContainsKey("mode")) ab.Str["mode"] = old.Str["mode"];
                    Features.Remove("drag_" + p);
                }
            }

            if (Array.IndexOf(ThemeNames, Theme) < 0) Theme = "Midnight";
            if (string.IsNullOrEmpty(UiKey)) UiKey = "INSERT";
            if (string.IsNullOrEmpty(PanicKey)) PanicKey = "F12";
            if (UiKey == PanicKey) PanicKey = UiKey == "F12" ? "F11" : "F12";
            if (Fps < 30) Fps = 144;

            // older versions had delays that were too fast -> apply the slower defaults once
            if (Version < 2)
            {
                TapMs = 25;
                foreach (var spec in Specs.All)
                {
                    var f = Features[spec.Id];
                    f.Delay = spec.Delay;
                    foreach (var o in spec.Opts) if (o.Type == "slider") f.Num[o.Key] = o.DefInt;
                }
                Version = 2;
            }

            // the new UI has no on/off switch per macro: a macro is active when it has a key
            if (Version < 3)
            {
                foreach (var spec in Specs.All)
                {
                    if (spec.Auto) continue;
                    var f = Features[spec.Id];
                    if (spec.Kind == "autobuild") f.Enabled = Specs.Pieces.Any(pc => !string.IsNullOrEmpty(f.Str["bind_" + pc]));
                    else f.Enabled = !string.IsNullOrEmpty(f.Bind);
                }
                Version = 3;
            }
        }
    }

    public static class Specs
    {
        public static readonly string[] Cells = { "Center", "Top Left", "Top", "Top Right", "Left", "Right", "Bottom Left", "Bottom", "Bottom Right" };
        public static readonly Dictionary<string, int[]> CellXY = new Dictionary<string, int[]>
        {
            { "Center", new[] { 0, 0 } }, { "Top Left", new[] { -1, -1 } }, { "Top", new[] { 0, -1 } }, { "Top Right", new[] { 1, -1 } },
            { "Left", new[] { -1, 0 } }, { "Right", new[] { 1, 0 } }, { "Bottom Left", new[] { -1, 1 } }, { "Bottom", new[] { 0, 1 } },
            { "Bottom Right", new[] { 1, 1 } },
        };
        public static readonly string[] Slots = { "Slot 1", "Slot 2", "Slot 3", "Slot 4", "Slot 5", "Slot 6", "Slot 7" };
        public static readonly string[] Pieces = { "wall", "floor", "ramp", "pyramid" };
        public static readonly List<FeatureSpec> All = new List<FeatureSpec>();
        public static readonly Dictionary<string, FeatureSpec> ById = new Dictionary<string, FeatureSpec>();

        static OptSpec OSlider(string key, string label, int def, int min, int max, string unit = " ms")
        { return new OptSpec { Type = "slider", Key = key, Label = label, DefInt = def, Min = min, Max = max, Unit = unit }; }
        static OptSpec OSwitch(string key, string label, bool def)
        { return new OptSpec { Type = "switch", Key = key, Label = label, DefInt = def ? 1 : 0 }; }
        static OptSpec OChoice(string key, string label, string def, params string[] ch)
        { return new OptSpec { Type = "choice", Key = key, Label = label, DefStr = def, Choices = ch }; }
        static OptSpec OBind(string key, string label)
        { return new OptSpec { Type = "bind", Key = key, Label = label, DefStr = "" }; }
        static OptSpec OTiles(string key, string label, string def)
        { return new OptSpec { Type = "tiles", Key = key, Label = label, DefStr = def }; }

        // "Once" = one press runs it once, "Hold" = loops for as long as you hold the key, "Toggle" = press to start / press to stop
        static List<OptSpec> Repeat(string defMode = "Hold")
        {
            return new List<OptSpec>
            {
                OChoice("mode", "Repeat mode", defMode, "Once", "Hold", "Toggle"),
                OSlider("repeat_gap", "Repeat gap", 1, 0, 100),
            };
        }

        static List<OptSpec> AutoReset()
        {
            return new List<OptSpec>
            {
                OSwitch("auto_reset", "Auto Reset after edit", false),
                OSlider("reset_delay", "Reset wait after edit", 120, 0, 500),
                OSlider("reset_step", "Reset step delay", 45, 0, 250),
            };
        }

        // tile-pattern options shared by Drag Edit and Single Edit (3x3 grid, 9-char mask, row by row)
        static List<OptSpec> TileOpts(string defTiles, string defConfirm)
        {
            return new List<OptSpec>
            {
                OChoice("start", "Crosshair starts on", "Center", Cells),
                OTiles("tiles", "Tiles to select", defTiles),
                OChoice("confirm", "Confirm by", defConfirm, "Release click", "Tap Edit", "Hold Edit"),
                OSlider("dist", "Move distance", 40, 5, 150, " px"),
                OSlider("steps", "Sweep steps", 5, 1, 12, ""),
                OSlider("step_delay", "Step delay", 6, 0, 100),
                OSlider("tile_dwell", "Time on each tile", 20, 0, 250),
                OSlider("release_delay", "Release delay", 40, 0, 250),
                OSwitch("return_aim", "Return aim after edit", true),
            };
        }

        static FeatureSpec Add(string id, string name, string kind, string cat, int delay, string dlabel, string sub,
                               List<OptSpec> opts, bool auto = false, int delayMax = 250)
        {
            var s = new FeatureSpec { Id = id, Name = name, Kind = kind, Cat = cat, Delay = delay, DelayLabel = dlabel, Sub = sub, Auto = auto, Opts = opts, DelayMax = delayMax };
            All.Add(s);
            ById[id] = s;
            return s;
        }

        static Specs()
        {
            // Editing
            var drag = Repeat();
            drag.AddRange(TileOpts("111000000", "Release click"));
            Add("drag_edit", "Drag Edit", "dragedit", "Editing", 40, "Grid delay", "Hold click, sweep over tiles", drag);

            var single = Repeat();
            single.Add(OSlider("click_hold", "Click hold", 45, 1, 250));
            single.AddRange(TileOpts("010010010", "Tap Edit"));
            Add("single_edit", "Single Edit", "single", "Editing", 40, "Grid delay", "Pick tiles, one press", single);

            var dbl = Repeat();
            dbl.Add(OSlider("click_hold", "Click hold", 45, 1, 250));
            dbl.Add(OSlider("gap", "Inter-structure delay", 110, 0, 400));
            dbl.AddRange(AutoReset());
            Add("double_edit", "Double Edit", "double", "Editing", 40, "Grid delay", "Edit two structures", dbl);

            var simple = Repeat();
            simple.Add(OSlider("click_hold", "Click hold", 45, 1, 250));
            simple.Add(OSwitch("confirm_edit", "Confirm with Edit key", false));
            simple.AddRange(AutoReset());
            Add("simple_edit", "Simple Edit", "edit", "Editing", 40, "Grid delay", "Edit + click center tile", simple);

            // Building
            Add("auto_build", "Auto Build", "autobuild", "Building", 10, "Equip to hold delay", "Wall, floor, ramp, pyramid",
                new List<OptSpec>
                {
                    OChoice("mode", "Mode", "Hold", "Hold", "Toggle"),
                    OSwitch("repress", "Re-press click (reliability)", false),
                    OBind("bind_wall", "Wall trigger"),
                    OBind("bind_floor", "Floor trigger"),
                    OBind("bind_ramp", "Ramp trigger"),
                    OBind("bind_pyramid", "Pyramid trigger"),
                });

            // Utility
            Add("weapon_pullout", "Weapon Pullout", "auto", "Utility", 0, "Fire delay", "Always on after an edit",
                new List<OptSpec>
                {
                    OChoice("slot", "Weapon slot", "Slot 1", Slots),
                    OSwitch("fire", "Fire on pullout", false),
                    OChoice("trigger", "Edit confirmed by", "Both", "Both", "Click release", "Edit key"),
                    OSlider("window", "Edit window", 3000, 500, 10000),
                    OSlider("equip_delay", "Equip delay", 15, 0, 250),
                }, true, 100);

            Add("auto_pickup", "Auto Pickup", "pickup", "Utility", 1, "Spam delay", "Spam the pickup key",
                new List<OptSpec>
                {
                    OChoice("mode", "Mode", "Hold", "Hold", "Toggle"),
                    OSlider("hold", "Press length", 2, 1, 50),
                }, false, 100);
        }
    }

    public static class Store
    {
        public static readonly string Dir = Path.Combine(AppContext.BaseDirectory, "config");
        static readonly JsonSerializerOptions Opt = new JsonSerializerOptions { WriteIndented = true };
        static string PathOf(string name) { return Path.Combine(Dir, name + ".json"); }

        public static List<string> Profiles()
        {
            var l = new List<string>();
            try
            {
                if (Directory.Exists(Dir))
                    foreach (var f in Directory.GetFiles(Dir, "*.json"))
                    {
                        var n = Path.GetFileNameWithoutExtension(f);
                        if (n != "_state") l.Add(n);
                    }
            }
            catch { }
            if (!l.Contains("default")) l.Add("default");
            l.Sort(StringComparer.OrdinalIgnoreCase);
            return l;
        }

        public static string Active()
        {
            try
            {
                var d = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(Path.Combine(Dir, "_state.json")));
                string a;
                if (d != null && d.TryGetValue("active", out a) && File.Exists(PathOf(a))) return a;
            }
            catch { }
            return "default";
        }

        public static Settings Load(string name)
        {
            try
            {
                var s = JsonSerializer.Deserialize<Settings>(File.ReadAllText(PathOf(name)));
                if (s != null) { s.Fix(); return s; }
            }
            catch (Exception e) { Log.E("load " + name + ": " + e.Message); }
            var n = new Settings();
            n.Fix();
            return n;
        }

        public static void Save(string name, Settings s)
        {
            try
            {
                Directory.CreateDirectory(Dir);
                File.WriteAllText(PathOf(name), JsonSerializer.Serialize(s, Opt));
                File.WriteAllText(Path.Combine(Dir, "_state.json"), JsonSerializer.Serialize(new Dictionary<string, string> { { "active", name } }));
            }
            catch (Exception e) { Log.E("save " + name + ": " + e.Message); }
        }

        public static Settings Clone(Settings s)
        {
            var c = JsonSerializer.Deserialize<Settings>(JsonSerializer.Serialize(s));
            c.Fix();
            return c;
        }

        public static void Delete(string name) { try { File.Delete(PathOf(name)); } catch { } }
    }
}
