using System.Threading;
using System.Windows;

namespace Shush
{
    public partial class App : Application
    {
        static Mutex single;

        public App()
        {
            DispatcherUnhandledException += (s, e) =>
            {
                Log.E("UI error: " + e.Exception);
                e.Handled = true;
            };
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            bool first;
            single = new Mutex(true, "Local\\ShushMacroTool_SingleInstance", out first);
            if (!first)
            {
                MessageBox.Show("Shush is already running (it may be hidden - press your show/hide key).\n\nIf it is stuck, end every \"shush\" process in Task Manager, or press Ctrl+Alt+Shift+F12.",
                                "Shush", MessageBoxButton.OK, MessageBoxImage.Information);
                Shutdown();
                return;
            }
            base.OnStartup(e);
        }
    }
}
